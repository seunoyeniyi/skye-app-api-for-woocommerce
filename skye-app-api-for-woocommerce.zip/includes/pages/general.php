<h1><?php esc_html_e( 'Site App - General Settings', 'sk_options' ); ?></h1>
<?php
