<?php
define("ENABLE_SLIDING_BANNER", true);
define("ENABLE_SCROLLING_BANNER", true);
define("ENABLE_GRID_BANNER", true);
define("ENABLE_SCROLLING_CATEGORIES", true);
define("ENABLE_GRID_CATEGORIES", true);