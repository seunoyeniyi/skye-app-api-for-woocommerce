=== Skye App API for WooCommerce ===
Contributors: seunoyeniyi
Donate link: https://github.com/seunoyeniyi
Tags: comments, spam
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

API to use for your APP development either Mobile, Desktop, or Web APP. eg: https://yourwebsite.com/wp-json/skye-api/v1/product=1. Easy to use, simple Uri, custom cart and more.

== Description ==

API to use for your APP development either Mobile, Desktop, or Web APP. eg: https://yourwebsite.com/wp-json/skye-api/v1/product=1. Easy to use, simple Uri, custom cart and more.

Activate the free Skye API plugin on a new or existing WordPress site, follow the optional guided tour, and set up a nice REST API for your app development with:

- Products, 
- Cart
- Orders
- Users
- Site information



== Frequently Asked Questions ==

= Can user cart be also used on website? =

Will be added soon.

= Is it possible to register new users? =

Yes... New user can be added, and be authenticated

== Screenshots ==

1. screenshot-1.png
2. Check the plugin Uri

== Changelog ==

= 1.0 =
* Latest version
*Check the plugin Uri for more versions.

== Upgrade Notice ==

= 1.0 =
Latest version.